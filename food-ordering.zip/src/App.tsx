import React from 'react';
import './App.scss';

import Header from './layout/header/Header';
import Main from './layout/main/Main';
import Footer from './layout/footer/Footer';

import SearchState from './context/search/SearchState';

const App = () => {



  return (
    <SearchState>
      <div className="App">
        <Header/>
        <Main/>
        <Footer/>
      </div>
    </SearchState>
  );
};

export default App;
