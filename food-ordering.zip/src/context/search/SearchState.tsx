import React, { useState, useReducer } from 'react';
import SearchContext from './searchContext';
import SearchReducer from './searchReducer';
import {
    SEARCH_FOOD,
    SET_LOADING,
    ENABLE_SO_POPUP,
    DISABLE_SO_POPUP,
    SET_SEARCH_OPTIONS,
} from '../types';

export type FoodItem = {
    id: number;
    name: string;
    image: string;
};

type SearchOptions = {
    resultsPerPage: number;
    sortBy: string;
    sortDirection: string;
    _limitResults: boolean;
    _resultLimit: number;
}


type Pagination = {
    page: number;
    itemOffset: number;
}

export type SearchType = {
    foodItems: Array<FoodItem> | null,
    totalResults: number | null,
    loading: boolean,
    soPopupEnabled: boolean,
    searchOptions: SearchOptions,
    pagination: Pagination,
    setLoading: Function,
    searchFood: Function,
    enableSOPopup: Function,
    disableSOPopup: Function,
    setSearchOptions: Function,
};


export enum SortBy {
    None = 'None',
    Calories = 'Calories',
    Price = 'Price',
};

export enum SortDirection {
    Asc = 'Asc',
    Desc = 'Desc',
};

export const resultsPerPageValues = [5, 10, 25, 50];

export const initialState: SearchType = {
    foodItems: null,
    totalResults: null,
    loading: false,
    soPopupEnabled: false,
    searchOptions: {
        resultsPerPage: resultsPerPageValues[1],
        sortBy: SortBy.Calories,
        sortDirection: SortDirection.Desc,
        _limitResults: false,
        _resultLimit: 20,
    },
    pagination: {
        page: 1,
        itemOffset: 0,
    },
    setLoading: ()=>{},
    searchFood: ()=>{},
    enableSOPopup: ()=>{},
    disableSOPopup: ()=>{},
    setSearchOptions: ()=>{},
};

const SearchState = (props: any) => {

    const [state, dispatch] = useReducer(SearchReducer, initialState);
    //!!!Is this the best way to do this?
    const [stateSearchOptions, setStateSearchOptions] = useState<SearchOptions>(initialState.searchOptions);

    //Set Loading
    const setLoading = () => dispatch({ type: SET_LOADING });

    //Search For Food
    const searchFood = async (search: string) => {

        const { resultsPerPage, sortBy, sortDirection, _limitResults } = stateSearchOptions;

        const endPointUrl = `https://api.spoonacular.com/food/ingredients/search?query=${search}&number=${!_limitResults ? resultsPerPage : _limitResults}&sort=${sortBy.toLowerCase()}&sortDirection=${sortDirection.toLowerCase()}&apiKey=${process.env.REACT_APP_SPOONACULAR_API_KEY}`;
        
        setLoading();

        const response = await fetch(endPointUrl);
        const myJson = await response.json();

        console.log(myJson);

        dispatch({
            type: SEARCH_FOOD,
            payload: myJson
        });

    };

    const enableSOPopup = () => dispatch({ type: ENABLE_SO_POPUP });

    const disableSOPopup = () => dispatch({ type: DISABLE_SO_POPUP });

    const setSearchOptions = (newOptions: SearchOptions) => {

        setStateSearchOptions(newOptions);

        dispatch({
            type: SET_SEARCH_OPTIONS,
            payload: newOptions
        });

    };

    return <SearchContext.Provider
        value={{
            foodItems: state.foodItems,
            totalResults: state.totalResults,
            loading: state.loading,
            soPopupEnabled: state.soPopupEnabled,
            searchOptions: state.searchOptions,
            pagination: state.pagination,
            setLoading,
            searchFood,
            enableSOPopup,
            disableSOPopup,
            setSearchOptions,
        }}
    >
        {props.children}
    </SearchContext.Provider>

}

export default SearchState;