import {
    SEARCH_FOOD,
    SET_LOADING,
    ENABLE_SO_POPUP,
    DISABLE_SO_POPUP,
        SET_SEARCH_OPTIONS,
} from '../types';
import { SearchType } from './SearchState';

function SearchReducer(state: SearchType, action: any) {
    switch(action.type) {
        case SET_LOADING:
            return {
                ...state,
                loading: true
            }
        case SEARCH_FOOD:
            return {
                ...state,
                foodItems: action.payload.results,
                totalResults: action.payload.totalResults,
                loading: false
            }
        case ENABLE_SO_POPUP:
            return {
                ...state,
                soPopupEnabled: true
            }
        case DISABLE_SO_POPUP:
            return {
                ...state,
                soPopupEnabled: false
            }
        case SET_SEARCH_OPTIONS:
            return {
                ...state,
                searchOptions: action.payload,
                soPopupEnabled: false
            }
        default:
            return state;
    }
};

export default SearchReducer;