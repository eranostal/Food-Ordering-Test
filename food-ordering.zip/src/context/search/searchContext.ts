import { createContext } from 'react';
import { SearchType, initialState } from './SearchState';

const searchContext = createContext<SearchType>(initialState);

export default searchContext;