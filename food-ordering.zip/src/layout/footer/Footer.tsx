import React from 'react';

import './Footer.scss';

const Footer = () => {

    return (
        <footer>
            <div className='madeBy'>Keith Novack 2022</div>
            <div className='links'>Personal Website</div>
        </footer>
    )
}

export default Footer;