import React from 'react';
import './Header.scss';

import Logo from '../../components/logo/Logo';
import Search from '../../components/search/Search';
import CartWidget from '../../widgets/cartWidget/CartWidget';

const Header = () => {

    return (
        <header>
            <div className='logoSearch'>
                <Logo/>
                <Search/>
            </div>
            <CartWidget/>
        </header>
    )
};

export default Header;