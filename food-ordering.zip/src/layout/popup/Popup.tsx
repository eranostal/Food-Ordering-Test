import React from 'react';
import './Popup.scss';

type PopupProps = {
    closePopup: Function,
    children: any
}

const Popup = ({ closePopup, children }: PopupProps) => {

    return (
        <div className='popup'>
            <div className='popupBounds' onClick={() => closePopup()}></div>
            <div className='popupInner'>
                <input type='button'  className='popupClose' value='x' onClick={() => closePopup()}/>
                { children }
            </div>
        </div>
    )
}

export default Popup;