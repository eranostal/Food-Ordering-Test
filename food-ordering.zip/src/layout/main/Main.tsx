import React, { Fragment, useContext } from 'react';
import './Main.scss';
import SearchContext from '../../context/search/searchContext';

import FoodItem from '../../components/foodItem/FoodItem';
import LoadingWidget from '../../widgets/loadingWidget/LoadingWidget';

const Main = () => {

    const { searchOptions: { resultsPerPage }, foodItems, totalResults, loading } = useContext(SearchContext);

    const PageSearch = () => {

        //Round up the pages
        const numPages = Math.ceil((totalResults || 0) / resultsPerPage);

        //START HERE OPTIONS NOT SHOWING UP
        return (
            <select>
                {
                    Array(numPages).map(() => (
                        <option>Hi</option>
                    ))
                }
            </select>    
        )
    };

    return (
        <main>
            <div className='foodItems'>
                {loading && <LoadingWidget/>}
                {foodItems !== null ? (
                    totalResults === 0 ? (
                            <div className='noResults'>No Results For Search...</div>
                        ) : (
                            <Fragment>
                                <div className='results'>
                                    {
                                        foodItems.map(foodItem => (
                                            <FoodItem key={foodItem.id} foodItem={foodItem}/>
                                        ))
                                    }
                                </div>
                                <div className='resultsPagination'>Showing { (totalResults !== null && totalResults > resultsPerPage) ? resultsPerPage : totalResults } of { totalResults } results <PageSearch/></div>
                            </Fragment>
                        )
                ) : (
                    <div className='pleaseSearch'>Please Search For A Food</div>
                )}
            </div>
        </main>
    )
};

export default Main;