import React from 'react';
import './LoadingWidget.scss';

const LoadingWidget = () => {

    return (
        <div className='loading'>
            Loading
        </div>
    )
}

export default LoadingWidget;