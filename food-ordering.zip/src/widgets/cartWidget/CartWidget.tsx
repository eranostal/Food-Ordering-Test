import React, { useState, Fragment } from 'react';
import './CartWidget.scss';

import Cart from '../../components/cart/Cart';

const CartWidget = () => {

    const [cartOpen, setCartOpen] = useState(false);

    return (
        <Fragment>
            <div className={cartOpen ? 'cartWidget open' : 'cartWidget'} onClick={() => setCartOpen(!cartOpen)}>
                Cart (0)
            </div>
            <Cart cartOpen={cartOpen}/>
        </Fragment>
    )
}

export default CartWidget;