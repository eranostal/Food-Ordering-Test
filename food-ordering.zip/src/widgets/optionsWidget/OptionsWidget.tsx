import React, { useContext } from 'react';
import './OptionsWidget.scss';

import SearchContext from '../../context/search/searchContext';

const OptionsWidget = () => {

    const { enableSOPopup } = useContext(SearchContext);

    const enableSearchOptions = () => {
        enableSOPopup();
    }

    return (
        <input type='button' onClick={() => enableSearchOptions()} value='Cog'/>
    )
}

export default OptionsWidget;