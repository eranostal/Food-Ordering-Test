import React, { useState, useContext } from 'react';
import './SearchOptions.scss';

import Popup from '../../layout/popup/Popup';
import SearchContext from '../../context/search/searchContext';
import { resultsPerPageValues, initialState, SortBy, SortDirection } from '../../context/search/SearchState';

const SearchOptions = () => {

    const { soPopupEnabled, disableSOPopup, setSearchOptions } = useContext(SearchContext);
    const { searchOptions } = initialState;

    const [newOptions, setNewOptions] = useState({
        resultsPerPage: searchOptions.resultsPerPage,
        sortBy: searchOptions.sortBy,
        sortDirection: searchOptions.sortDirection,
        _limitResults: searchOptions._limitResults,
        _resultLimit: searchOptions._resultLimit,
    });

    const ResultsPerPageOption = () => (
        <select value={newOptions.resultsPerPage} onChange={(e) => setNewOptions({...newOptions, resultsPerPage: Number(e.target.value)})}>
            { resultsPerPageValues.map(val => (
                <option value={val}>{ val }</option>
            ))}
        </select>
    )

    const SortByOption = () => (
        <select value={newOptions.sortBy} onChange={(e) => setNewOptions({...newOptions, sortBy: e.target.value})}>
            {
                Object.keys(SortBy).map((key) => (
                    <option key={key}>{ key }</option>
                ))
            }
        </select>
    );

    const SortDirectionOption = () => (
        <select value={newOptions.sortDirection} onChange={(e) => setNewOptions({...newOptions, sortDirection: e.target.value})}>
            {
                Object.keys(SortDirection).map((key) => (
                    <option key={key}>{ key }</option>
                ))
            }
        </select>
    )

    const applyOptions = () => {

        //If no change, disable popup and return.
        if(JSON.stringify(searchOptions) === JSON.stringify(newOptions)) {
            resetOptions();
            return;
        }

        setSearchOptions(newOptions);

    }

    const resetOptions = () => {
        //Reset options
        setNewOptions(searchOptions);
        disableSOPopup();
    }

    if(soPopupEnabled) {
        return (
            <Popup closePopup={resetOptions}>
                <fieldset className='searchOptions'>
                    <div className='field'>
                        <label className='searchOption'>Results Per Page:</label>
                        <ResultsPerPageOption/>
                    </div>
                    <div className='field'>
                        <label className='searchOption'>Sort By:</label>
                        <SortByOption/>
                    </div>
                    <div className='field'>
                        <label className='searchOption'>Sort Direction:</label>
                        <SortDirectionOption/>
                    </div>
                    <div className='field'>
                        <label className='searchOption'>Limit Results:*</label>
                        <input type='checkbox' onChange={(e) => setNewOptions({...newOptions, _limitResults: e.target.checked})}/>
                    </div>
                    { newOptions._limitResults && (
                        <div className='field'>
                            <label className='searchOption'>Result Limit:*</label>
                            <input type='number' value={newOptions._resultLimit}/>
                        </div>
                    )}
                </fieldset>
                <input type='button' className='applyOptions' value='Apply' onClick={() => applyOptions()}/>
            </Popup>
        )
    } else {
        return null;
    }
};

export default SearchOptions;