import React from 'react';
import './Cart.scss';

type CartProps = {
    cartOpen: boolean;
};

const Cart = ({ cartOpen }: CartProps) => {

    return (
        <div className={ cartOpen ? 'cart open' : 'cart'}>
            Your cart is empty
        </div>
    )
};

export default Cart;