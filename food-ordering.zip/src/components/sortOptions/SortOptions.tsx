import React from 'react';

const SortOptions = () => {

    return (
        <div>
            Sort Options!
        </div>
    )
};

export default SortOptions;