import React from 'react';
import './AddToCart.scss';

const AddToCart = () => {

    return (
        <div className='addToCart'>
            <input type='button' value='-'/> 0 <input type='button' value='+'/>
        </div>
    )
}

export default AddToCart;