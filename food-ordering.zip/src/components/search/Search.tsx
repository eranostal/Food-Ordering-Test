import React, { useState, useContext, Fragment } from 'react';
import './Search.scss';

import SearchContext from '../../context/search/searchContext';
import OptionsWidget from '../../widgets/optionsWidget/OptionsWidget';
import SearchOptions from '../../components/searchOptions/SearchOptions';

const Search = () => {

    const { searchFood } = useContext(SearchContext);

    const [search, setSearch] = useState('');

    const searchForFood = () => {
        searchFood(search);
    }

    return (
        <Fragment>
            <div className='foodSearch'>
                <input id='foodSearchInput' className='foodSearchInput' type='search' onChange={(e) => setSearch(e.target.value)} placeholder='e.g. Bananas'/>
                <input id='foodSearchBtn' className='foodSearchBtn' type='button' onClick={searchForFood} value='Search'/>
            </div>
            <OptionsWidget/>
            <SearchOptions/>
        </Fragment>
    )
};

export default Search;