import React from 'react';
import './Logo.scss';

const Logo = () => (
    <div className='logo'>
        Food Searcher!
    </div>
);

export default Logo;