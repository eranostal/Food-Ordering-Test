import React from 'react';
import './FoodItem.scss';

import { FoodItem as FItem } from '../../context/search/SearchState';
import AddToCart from '../addToCart/AddToCart';

type FoodItemProps = {
    foodItem: FItem;
}

const FoodItem = ({ foodItem }: FoodItemProps) => {


    const { name, image } = foodItem;

    const imgSize = '250x250'; //100x100, 250x250, 500x500
    const imgPath = `https://spoonacular.com/cdn/ingredients_${imgSize}/${image}`;

    return (
        <div className='foodItem'>
            <picture>
                <img alt={name} src={imgPath}/>
            </picture>
            <div className='foodInfo'>
                <article>
                    { name }
                </article>
                <AddToCart/>
            </div>
        </div>
    )
};

export default FoodItem;